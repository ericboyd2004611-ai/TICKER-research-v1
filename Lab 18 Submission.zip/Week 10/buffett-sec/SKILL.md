---
name: buffett-sec
description: Use for Lab 18 Buffett-style business-quality analysis of a ticker using five fiscal years of SEC EDGAR 10-K company facts, code-computed checks, and a numerically audited memo. Excludes stock-price valuation and paid data services.
---

# Buffett business-quality screen

Read `references/buffett.md` for the adapted philosophy and assignment boundaries. Never install, invoke, or fetch data through FAskills or paid financial services. The model supplies judgment; the bundled Python supplies every number.

Run the bundled script with the requested ticker, a real SEC User-Agent naming the user and their email, and a writable output directory:

```sh
python scripts/sec_facts.py COST --user-agent 'Name email' --output /path/to/reports
```

It fetches only SEC's ticker mapping and companyfacts JSON, archives source bytes and hashes, prints a report, and saves `<TICKER>_report.md` and `<TICKER>_report.json`. `--facts-file` and `--tickers-file` replay archived inputs without network requests. Read the report before writing a memo.

Accounting rules are fixed: 10-K only, annual flows (330–380 elapsed days, including retail 52/53-week years), five latest fiscal-year-end dates, latest filing for the same period wins. Prefer the specified revenue and capital-spending tags within the selected latest filing. Never group comparative facts by `fy`, which names the filing's fiscal year. Use end dates and exact annual start/end periods. Instant equity must have the same end date. Missing raw facts are `not found`; derived values or checks with missing inputs are `not known`; equity at or below zero makes ROE and liabilities/equity `not known`.

The script defines ROE as net income / year-end equity and the lab's owner earnings as operating cash flow minus total capital spending. It calculates the three checks: ROE >=15% every year; positive owner earnings every year; owner earnings last year > first year. All five years must be available for a check to be known. This is a latest-filed screen, not a historical point-in-time backtest.

Write `<TICKER>_memo.md` as a short first-person Buffett-inspired educational memo, explicitly a model simulation rather than Buffett's actual opinion. Choose **Own the business**, **Watch it**, or **Pass**. Assess business quality, not market price. Use only numbers/formats printed by the script; do not calculate new quantities in prose. Do not invent scores, forecasts, moat facts, or management claims. Distinguish numerical evidence from qualitative inference. A passing screen supports an assessment, not proof of a durable moat. State what would change the assessment.

Audit and bind the memo to its exact report:

```sh
python scripts/sec_facts.py --audit-memo /path/to/reports/COST_memo.md --report-json /path/to/reports/COST_report.json
```

Correct every unsupported number and rerun the audit. The audit saves a memo-source fingerprint, which the app uses to warn about stale memos. It checks numeric tokens, not whether a supported number is used with the correct meaning; review periods, units and claims yourself. Leave a failed audit visible rather than silently removing warnings.

If SEC access fails, report the error; do not substitute another data provider, fabricated annual values, or the expected COST trend. If fewer fiscal years are available, retain missing rows and unknown checks instead of claiming a five-year pass.
