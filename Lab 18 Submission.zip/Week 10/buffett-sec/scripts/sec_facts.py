"""SEC-only annual Buffett screen; standard library, no API keys."""
import argparse
from datetime import date, datetime, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import time
from urllib.request import Request, urlopen

TICKERS_URL = 'https://www.sec.gov/files/company_tickers.json'
TAGS = {
    'revenue': ['RevenueFromContractWithCustomerExcludingAssessedTax', 'Revenues'],
    'net_income': ['NetIncomeLoss'],
    'operating_cash_flow': ['NetCashProvidedByUsedInOperatingActivities'],
    'capital_spending': ['PaymentsToAcquirePropertyPlantAndEquipment', 'PaymentsToAcquireProductiveAssets'],
    'equity': ['StockholdersEquity'],
    'liabilities': ['Liabilities'],
}
FLOW_FIELDS = ('revenue', 'net_income', 'operating_cash_flow', 'capital_spending')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def fetch(url, user_agent):
    if not re.search(r'\S+@\S+\.\S+', user_agent) or len(user_agent.split()) < 2:
        raise ValueError('SEC User-Agent must name you and include your email.')
    with urlopen(Request(url, headers={'User-Agent': user_agent, 'Accept': 'application/json'}), timeout=60) as response:
        return response.read()


def annual(row):
    if row.get('form') != '10-K' or row.get('fp') != 'FY' or not row.get('start'):
        return False
    days = (date.fromisoformat(row['end']) - date.fromisoformat(row['start'])).days
    return 330 <= days <= 380


def candidates(facts, field):
    gaap = facts.get('facts', {}).get('us-gaap', {})
    result = []
    for priority, tag in enumerate(TAGS[field]):
        for raw in gaap.get(tag, {}).get('units', {}).get('USD', []):
            if raw.get('form') != '10-K' or raw.get('fp') != 'FY':
                continue
            if field in FLOW_FIELDS and not annual(raw):
                continue
            if field not in FLOW_FIELDS and 'start' in raw:
                continue
            if not isinstance(raw.get('val'), (int, float)):
                continue
            result.append({**raw, 'tag': tag, 'priority': priority})
    return result


def choose(rows, end, start=None):
    matches = [r for r in rows if r['end'] == end and (start is None or r.get('start') == start)]
    if not matches:
        return {'value': None, 'tag': 'not found'}
    # Latest filing wins across aliases; tag preference breaks ties within it.
    latest = max((r['filed'], r['accn']) for r in matches)
    matches = [r for r in matches if (r['filed'], r['accn']) == latest]
    priority = min(r['priority'] for r in matches)
    matches = [r for r in matches if r['priority'] == priority]
    if len({(r.get('start'), r['val']) for r in matches}) != 1:
        raise ValueError(f'Conflicting annual facts for {end}; cannot choose safely.')
    r = matches[0]
    return {'value': r['val'], 'tag': r['tag'], 'start': r.get('start'), 'end': r['end'],
            'filed': r['filed'], 'accn': r['accn'], 'form': r['form'], 'unit': 'USD'}


def derived(value, tag):
    return {'value': value, 'tag': tag}


def check(values, predicate, required=5):
    if len(values) != required or any(v is None for v in values):
        return 'not known'
    return 'pass' if predicate(values) else 'fail'


def analyze(facts, ticker):
    rows = {field: candidates(facts, field) for field in TAGS}
    # End dates, not SEC fy labels, identify the measured fiscal year.
    ends = sorted({r['end'] for field in FLOW_FIELDS for r in rows[field]})[-5:]
    if not ends:
        raise ValueError('No annual USD facts from 10-K filings found.')
    records = []
    for end in ends:
        annual_rows = [r for field in FLOW_FIELDS for r in rows[field] if r['end'] == end]
        latest = max((r['filed'], r['accn']) for r in annual_rows)
        starts = {r['start'] for r in annual_rows if (r['filed'], r['accn']) == latest}
        if len(starts) != 1:
            raise ValueError(f'Ambiguous one-year period ending {end}.')
        start = starts.pop()
        metrics = {field: choose(rows[field], end, start if field in FLOW_FIELDS else None) for field in TAGS}
        value = lambda field: metrics[field]['value']
        ni, eq = value('net_income'), value('equity')
        ocf, capex, liabilities = value('operating_cash_flow'), value('capital_spending'), value('liabilities')
        metrics['roe'] = derived(ni / eq * 100 if ni is not None and eq is not None and eq > 0 else None,
                                 f"{metrics['net_income']['tag']} / {metrics['equity']['tag']} × 100")
        metrics['owner_earnings'] = derived(ocf - capex if ocf is not None and capex is not None else None,
                                            f"{metrics['operating_cash_flow']['tag']} − {metrics['capital_spending']['tag']}")
        metrics['liabilities_to_equity'] = derived(liabilities / eq if liabilities is not None and eq is not None and eq > 0 else None,
                                                  f"{metrics['liabilities']['tag']} / {metrics['equity']['tag']}")
        records.append({'fiscal_year_end': end, 'annual_start': start, 'metrics': metrics})
    roes = [r['metrics']['roe']['value'] for r in records]
    earnings = [r['metrics']['owner_earnings']['value'] for r in records]
    checks = {
        'ROE >= 15% every year': check(roes, lambda v: all(x >= 15 for x in v)),
        'Owner earnings positive every year': check(earnings, lambda v: all(x > 0 for x in v)),
        'Owner earnings grew, first year to last': check(earnings, lambda v: v[-1] > v[0]),
    }
    return {'ticker': ticker, 'company': facts.get('entityName', ticker), 'cik': int(facts['cik']),
            'records': records, 'checks': checks}


def display(metric, field):
    value = metric['value']
    if value is None:
        return 'not found' if field in TAGS else 'not known'
    if field == 'roe':
        return f'{value:.2f}%'
    if field == 'liabilities_to_equity':
        return f'{value:.2f}'
    return f'{value / 1_000_000:,.2f}'


def render(report):
    lines = [f"# {report['ticker']} — {report['company']}", '',
             'Source: SEC EDGAR companyfacts; 10-K only. Monetary values in USD millions.',
             'Five fiscal years; annual flows cover 330–380 days; latest filing wins.',
             'ROE = net income / year-end equity. Owner earnings = operating cash flow − capital spending.', '',
             '| Fiscal-year-end | Metric | Value | XBRL tag / formula |', '|---|---|---:|---|']
    for record in report['records']:
        for field, metric in record['metrics'].items():
            lines.append(f"| {record['fiscal_year_end']} | {field} | {display(metric, field)} | {metric['tag']} |")
    lines.extend(['', '## Checks', ''])
    lines.extend(f'- {name}: **{result}**' for name, result in report['checks'].items())
    lines.extend(['', '## Source periods and filings', ''])
    for record in report['records']:
        lines.append(f"Fiscal-year-end {record['fiscal_year_end']}; annual start {record['annual_start']}.")
        for field in TAGS:
            m = record['metrics'][field]
            if m['value'] is not None:
                lines.append(f"- {field}: {m['accn']}, filed {m['filed']}, us-gaap:{m['tag']}; USD.")
    return '\n'.join(lines) + '\n'


NUMBER = re.compile(r'[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?%?')


def number_key(text):
    return (Decimal(text.rstrip('%').replace(',', '')), text.endswith('%'))


def audit_memo(memo, printed):
    supported = {number_key(m.group()) for m in NUMBER.finditer(printed)}
    return [{'number': m.group(), 'start': m.start(), 'end': m.end()}
            for m in NUMBER.finditer(memo) if number_key(m.group()) not in supported]


def run(ticker, user_agent, output, facts_file=None, tickers_file=None):
    ticker = ticker.strip().upper()
    if not re.fullmatch(r'[A-Z0-9.-]+', ticker):
        raise ValueError('Enter a ticker using letters, numbers, dots or hyphens.')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    tickers_raw = Path(tickers_file).read_bytes() if tickers_file else fetch(TICKERS_URL, user_agent)
    mapping = json.loads(tickers_raw)
    company = next((r for r in mapping.values() if r['ticker'].upper() == ticker), None)
    if company is None:
        raise ValueError(f'{ticker}: ticker not found in SEC mapping.')
    cik = int(company['cik_str'])
    url = f'https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json'
    if not facts_file:
        time.sleep(0.2)
    raw = Path(facts_file).read_bytes() if facts_file else fetch(url, user_agent)
    facts = json.loads(raw)
    if int(facts['cik']) != cik:
        raise ValueError('Ticker mapping and facts CIK do not match.')
    report = analyze(facts, ticker)
    report['source'] = {'ticker_url': TICKERS_URL, 'facts_url': url, 'retrieved_utc': datetime.now(timezone.utc).isoformat(),
                        'facts_sha256': digest(raw), 'tickers_sha256': digest(tickers_raw),
                        'mode': 'archived input replay' if facts_file else 'live SEC download'}
    printed = render(report)
    report['printed'] = printed
    report['analysis_sha256'] = digest(printed.encode())
    (output / f'{ticker}_companyfacts.json').write_bytes(raw)
    (output / 'company_tickers.json').write_bytes(tickers_raw)
    (output / f'{ticker}_report.json').write_text(json.dumps(report, indent=2))
    (output / f'{ticker}_report.md').write_text(printed)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ticker', nargs='?')
    parser.add_argument('--user-agent', default='')
    parser.add_argument('--output', default='reports')
    parser.add_argument('--facts-file')
    parser.add_argument('--tickers-file')
    parser.add_argument('--audit-memo')
    parser.add_argument('--report-json')
    args = parser.parse_args()
    if args.audit_memo:
        report = json.loads(Path(args.report_json).read_text())
        memo_path = Path(args.audit_memo)
        memo = memo_path.read_text()
        flags = audit_memo(memo, report['printed'])
        result = {'ticker': report['ticker'], 'analysis_sha256': report['analysis_sha256'],
                  'memo_sha256': digest(memo.encode()), 'unsupported_numbers': flags}
        memo_path.with_suffix('.audit.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result, indent=2))
        return 1 if flags else 0
    if not args.ticker:
        parser.error('Supply a ticker.')
    try:
        report = run(args.ticker, args.user_agent, args.output, args.facts_file, args.tickers_file)
        print(report['printed'], end='')
    except Exception as error:
        parser.exit(1, f'Could not produce a verified SEC screen: {error}\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
