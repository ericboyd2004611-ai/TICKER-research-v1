# Adapted philosophy and boundaries

Read-only source: [FAskills Buffett expert page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/warren_buffett.md), read November 3, 2026. Its useful business-quality themes are understandable economics, durable competitive advantage, consistent cash generation, management's allocation of capital, and conservative financing. This skill does not execute its orchestration or use its data providers. Its price targets, valuation assumptions, forecasts, and numeric scoring requests are outside this lab.

The assignment's simplified owner earnings is operating cash flow minus capital spending. It is not an estimate of Buffett's maintenance-capex-adjusted economic owner earnings. Do not replace the assigned formula with the page's formula. Buffett's [1986 letter](https://www.berkshirehathaway.com/letters/1986.html) explains why maintenance expenditure entails judgment; this lab avoids estimating it.

Use the code's checks as evidence of business quality. Judge whether the pattern is convincing, what the checks cannot establish, and what evidence would change the judgment. No share price, price target, discount rate, margin of safety, or purchase recommendation at a quoted price.

Sources: [SEC API documentation](https://www.sec.gov/search-filings/edgar-application-programming-interfaces); [Codex skill discovery locations](https://learn.chatgpt.com/docs/build-skills). Companyfacts supplies standard-taxonomy, entity-wide facts; custom-only facts may be unavailable and must remain missing.
