# COST — Own the business

*Buffett-inspired model judgment for the lab; not Warren Buffett's actual opinion. All dollar amounts below are USD millions. This judges business quality, not the stock's price.*

I would want to own this business on the financial evidence presented. Owner earnings rose from 3,501.00 in the earliest fiscal year to 9,382.00 in the latest, while net income rose from 5,844.00 to 9,226.00. Owner earnings stayed positive throughout, and ROE cleared 15% in every year. Those are the habits I look for in a business that can generate cash for its owners.

I would not mistake that screen for proof of a moat or management integrity. Owner earnings slipped from 6,745.00 to 6,629.00 before recovering; the endpoint growth check does not mean cash generation increased every year. The latest liabilities-to-equity ratio is 1.49, and the ROE calculation uses year-end equity, so I would examine how financing and distributions affect that return. The lab's owner earnings deducts all capital spending; it is a consistent cash-flow screen, not a maintenance-spending estimate.

I would change my assessment if owner earnings became persistently negative, returns on equity weakened, or further filing evidence undermined the durability of the cash generation. Until the business model and competitive position have been examined in detail, this is a provisional business-quality judgment. There is no conclusion here about whether the shares are attractively priced.
