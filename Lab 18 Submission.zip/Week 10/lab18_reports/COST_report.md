# COST — COSTCO WHOLESALE CORP /NEW

Source: SEC EDGAR companyfacts; 10-K only. Monetary values in USD millions.
Five fiscal years; annual flows cover 330–380 days; latest filing wins.
ROE = net income / year-end equity. Owner earnings = operating cash flow − capital spending.

| Fiscal-year-end | Metric | Value | XBRL tag / formula |
|---|---|---:|---|
| 2022-08-28 | revenue | 226,954.00 | RevenueFromContractWithCustomerExcludingAssessedTax |
| 2022-08-28 | net_income | 5,844.00 | NetIncomeLoss |
| 2022-08-28 | operating_cash_flow | 7,392.00 | NetCashProvidedByUsedInOperatingActivities |
| 2022-08-28 | capital_spending | 3,891.00 | PaymentsToAcquirePropertyPlantAndEquipment |
| 2022-08-28 | equity | 20,642.00 | StockholdersEquity |
| 2022-08-28 | liabilities | 43,519.00 | Liabilities |
| 2022-08-28 | roe | 28.31% | NetIncomeLoss / StockholdersEquity × 100 |
| 2022-08-28 | owner_earnings | 3,501.00 | NetCashProvidedByUsedInOperatingActivities − PaymentsToAcquirePropertyPlantAndEquipment |
| 2022-08-28 | liabilities_to_equity | 2.11 | Liabilities / StockholdersEquity |
| 2023-09-03 | revenue | 242,290.00 | RevenueFromContractWithCustomerExcludingAssessedTax |
| 2023-09-03 | net_income | 6,292.00 | NetIncomeLoss |
| 2023-09-03 | operating_cash_flow | 11,068.00 | NetCashProvidedByUsedInOperatingActivities |
| 2023-09-03 | capital_spending | 4,323.00 | PaymentsToAcquirePropertyPlantAndEquipment |
| 2023-09-03 | equity | 25,058.00 | StockholdersEquity |
| 2023-09-03 | liabilities | 43,936.00 | Liabilities |
| 2023-09-03 | roe | 25.11% | NetIncomeLoss / StockholdersEquity × 100 |
| 2023-09-03 | owner_earnings | 6,745.00 | NetCashProvidedByUsedInOperatingActivities − PaymentsToAcquirePropertyPlantAndEquipment |
| 2023-09-03 | liabilities_to_equity | 1.75 | Liabilities / StockholdersEquity |
| 2024-09-01 | revenue | 254,453.00 | RevenueFromContractWithCustomerExcludingAssessedTax |
| 2024-09-01 | net_income | 7,367.00 | NetIncomeLoss |
| 2024-09-01 | operating_cash_flow | 11,339.00 | NetCashProvidedByUsedInOperatingActivities |
| 2024-09-01 | capital_spending | 4,710.00 | PaymentsToAcquirePropertyPlantAndEquipment |
| 2024-09-01 | equity | 23,622.00 | StockholdersEquity |
| 2024-09-01 | liabilities | 46,209.00 | Liabilities |
| 2024-09-01 | roe | 31.19% | NetIncomeLoss / StockholdersEquity × 100 |
| 2024-09-01 | owner_earnings | 6,629.00 | NetCashProvidedByUsedInOperatingActivities − PaymentsToAcquirePropertyPlantAndEquipment |
| 2024-09-01 | liabilities_to_equity | 1.96 | Liabilities / StockholdersEquity |
| 2025-08-31 | revenue | 275,235.00 | RevenueFromContractWithCustomerExcludingAssessedTax |
| 2025-08-31 | net_income | 8,099.00 | NetIncomeLoss |
| 2025-08-31 | operating_cash_flow | 13,335.00 | NetCashProvidedByUsedInOperatingActivities |
| 2025-08-31 | capital_spending | 5,498.00 | PaymentsToAcquirePropertyPlantAndEquipment |
| 2025-08-31 | equity | 29,164.00 | StockholdersEquity |
| 2025-08-31 | liabilities | 47,935.00 | Liabilities |
| 2025-08-31 | roe | 27.77% | NetIncomeLoss / StockholdersEquity × 100 |
| 2025-08-31 | owner_earnings | 7,837.00 | NetCashProvidedByUsedInOperatingActivities − PaymentsToAcquirePropertyPlantAndEquipment |
| 2025-08-31 | liabilities_to_equity | 1.64 | Liabilities / StockholdersEquity |
| 2026-08-30 | revenue | 303,154.00 | RevenueFromContractWithCustomerExcludingAssessedTax |
| 2026-08-30 | net_income | 9,226.00 | NetIncomeLoss |
| 2026-08-30 | operating_cash_flow | 15,817.00 | NetCashProvidedByUsedInOperatingActivities |
| 2026-08-30 | capital_spending | 6,435.00 | PaymentsToAcquirePropertyPlantAndEquipment |
| 2026-08-30 | equity | 35,803.00 | StockholdersEquity |
| 2026-08-30 | liabilities | 53,242.00 | Liabilities |
| 2026-08-30 | roe | 25.77% | NetIncomeLoss / StockholdersEquity × 100 |
| 2026-08-30 | owner_earnings | 9,382.00 | NetCashProvidedByUsedInOperatingActivities − PaymentsToAcquirePropertyPlantAndEquipment |
| 2026-08-30 | liabilities_to_equity | 1.49 | Liabilities / StockholdersEquity |

## Checks

- ROE >= 15% every year: **pass**
- Owner earnings positive every year: **pass**
- Owner earnings grew, first year to last: **pass**

## Source periods and filings

Fiscal-year-end 2022-08-28; annual start 2021-08-30.
- revenue: 0000909832-24-000049, filed 2024-10-09, us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; USD.
- net_income: 0000909832-24-000049, filed 2024-10-09, us-gaap:NetIncomeLoss; USD.
- operating_cash_flow: 0000909832-24-000049, filed 2024-10-09, us-gaap:NetCashProvidedByUsedInOperatingActivities; USD.
- capital_spending: 0000909832-24-000049, filed 2024-10-09, us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; USD.
- equity: 0000909832-23-000042, filed 2023-10-11, us-gaap:StockholdersEquity; USD.
- liabilities: 0000909832-23-000042, filed 2023-10-11, us-gaap:Liabilities; USD.
Fiscal-year-end 2023-09-03; annual start 2022-08-29.
- revenue: 0000909832-25-000101, filed 2025-10-08, us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; USD.
- net_income: 0000909832-25-000101, filed 2025-10-08, us-gaap:NetIncomeLoss; USD.
- operating_cash_flow: 0000909832-25-000101, filed 2025-10-08, us-gaap:NetCashProvidedByUsedInOperatingActivities; USD.
- capital_spending: 0000909832-25-000101, filed 2025-10-08, us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; USD.
- equity: 0000909832-26-000093, filed 2026-10-07, us-gaap:StockholdersEquity; USD.
- liabilities: 0000909832-24-000049, filed 2024-10-09, us-gaap:Liabilities; USD.
Fiscal-year-end 2024-09-01; annual start 2023-09-04.
- revenue: 0000909832-26-000093, filed 2026-10-07, us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; USD.
- net_income: 0000909832-26-000093, filed 2026-10-07, us-gaap:NetIncomeLoss; USD.
- operating_cash_flow: 0000909832-26-000093, filed 2026-10-07, us-gaap:NetCashProvidedByUsedInOperatingActivities; USD.
- capital_spending: 0000909832-26-000093, filed 2026-10-07, us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; USD.
- equity: 0000909832-26-000093, filed 2026-10-07, us-gaap:StockholdersEquity; USD.
- liabilities: 0000909832-25-000101, filed 2025-10-08, us-gaap:Liabilities; USD.
Fiscal-year-end 2025-08-31; annual start 2024-09-02.
- revenue: 0000909832-26-000093, filed 2026-10-07, us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; USD.
- net_income: 0000909832-26-000093, filed 2026-10-07, us-gaap:NetIncomeLoss; USD.
- operating_cash_flow: 0000909832-26-000093, filed 2026-10-07, us-gaap:NetCashProvidedByUsedInOperatingActivities; USD.
- capital_spending: 0000909832-26-000093, filed 2026-10-07, us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; USD.
- equity: 0000909832-26-000093, filed 2026-10-07, us-gaap:StockholdersEquity; USD.
- liabilities: 0000909832-26-000093, filed 2026-10-07, us-gaap:Liabilities; USD.
Fiscal-year-end 2026-08-30; annual start 2025-09-01.
- revenue: 0000909832-26-000093, filed 2026-10-07, us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; USD.
- net_income: 0000909832-26-000093, filed 2026-10-07, us-gaap:NetIncomeLoss; USD.
- operating_cash_flow: 0000909832-26-000093, filed 2026-10-07, us-gaap:NetCashProvidedByUsedInOperatingActivities; USD.
- capital_spending: 0000909832-26-000093, filed 2026-10-07, us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; USD.
- equity: 0000909832-26-000093, filed 2026-10-07, us-gaap:StockholdersEquity; USD.
- liabilities: 0000909832-26-000093, filed 2026-10-07, us-gaap:Liabilities; USD.
