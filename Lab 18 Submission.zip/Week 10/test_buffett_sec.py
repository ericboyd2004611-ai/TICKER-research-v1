"""Meaningful accounting-selection and missing-data tests, no network."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
sys.path.insert(0, str(Path(__file__).parent / 'buffett-sec' / 'scripts'))
import sec_facts as E


def fixture():
    facts = {'cik': 1, 'entityName': 'Test', 'facts': {'us-gaap': {}}}
    for field, tags in E.TAGS.items():
        tag = tags[0]
        rows = []
        for year in range(2022, 2027):
            r = {'end': f'{year}-12-31', 'filed': f'{year+1}-02-01', 'accn': f'{year}-a',
                 'form': '10-K', 'fp': 'FY', 'fy': year, 'val': 100}
            if field in E.FLOW_FIELDS:
                r['start'] = f'{year}-01-01'
            if field == 'net_income': r['val'] = 20
            if field == 'capital_spending': r['val'] = 10
            rows.append(r)
        facts['facts']['us-gaap'][tag] = {'units': {'USD': rows}}
    return facts


class Accounting(unittest.TestCase):
    def test_latest_filing_not_fy_and_no_quarters_or_10q(self):
        f = fixture()
        rows = f['facts']['us-gaap']['NetIncomeLoss']['units']['USD']
        original = rows[0]
        rows.extend([{**original, 'filed': '2028-01-01', 'accn': 'latest', 'fy': 2027, 'val': 30},
                     {**original, 'filed': '2029-01-01', 'start': '2022-10-01', 'val': 900},
                     {**original, 'filed': '2030-01-01', 'form': '10-Q', 'val': 999}])
        result = E.analyze(f, 'TEST')
        self.assertEqual(result['records'][0]['metrics']['net_income']['value'], 30)
        self.assertEqual(result['records'][0]['fiscal_year_end'], '2022-12-31')

    def test_missing_input_and_nonpositive_equity(self):
        f = fixture()
        f['facts']['us-gaap']['StockholdersEquity']['units']['USD'][-1]['val'] = 0
        del f['facts']['us-gaap']['PaymentsToAcquirePropertyPlantAndEquipment']
        r = E.analyze(f, 'TEST')
        self.assertIsNone(r['records'][-1]['metrics']['roe']['value'])
        self.assertIsNone(r['records'][-1]['metrics']['liabilities_to_equity']['value'])
        self.assertEqual(set(r['checks'].values()), {'not known'})
        self.assertIn('not found', E.render(r))
        self.assertIn('not known', E.render(r))

    def test_fallback_then_latest_filing_wins(self):
        f = fixture()
        original = f['facts']['us-gaap']['RevenueFromContractWithCustomerExcludingAssessedTax']['units']['USD'][-1]
        f['facts']['us-gaap']['Revenues'] = {'units': {'USD': [{**original, 'filed': '2028-01-01', 'val': 123}]}}
        self.assertEqual(E.analyze(f, 'TEST')['records'][-1]['metrics']['revenue']['value'], 123)

    def test_conflicting_facts_fail_and_partial_history_unknown(self):
        f = fixture()
        rows = f['facts']['us-gaap']['NetIncomeLoss']['units']['USD']
        rows.append({**rows[-1], 'val': 999})
        with self.assertRaises(ValueError): E.analyze(f, 'TEST')
        f = fixture()
        for concept in f['facts']['us-gaap'].values():
            concept['units']['USD'] = concept['units']['USD'][-4:]
        self.assertEqual(set(E.analyze(f, 'TEST')['checks'].values()), {'not known'})

    def test_arithmetic_and_audit(self):
        result = E.analyze(fixture(), 'TEST')
        self.assertEqual(result['records'][-1]['metrics']['roe']['value'], 20)
        self.assertEqual(result['records'][-1]['metrics']['owner_earnings']['value'], 90)
        self.assertEqual(result['checks']['Owner earnings grew, first year to last'], 'fail')
        self.assertEqual(E.audit_memo('Income 9,226.00; ROE 25.77%.', '9,226.00 25.77%'), [])
        self.assertEqual([x['number'] for x in E.audit_memo('Invented 987654321 and 42%.', '1 2 3')], ['987654321', '42%'])


if __name__ == '__main__': unittest.main()
