# Lab 18 — Buffett’s philosophy as a repeatable SEC-only skill

Started and built November 3, 2026.

## Question and result

Can an investor’s philosophy become a repeatable skill—every number computed by code from the 10-K, the judgment the model’s?

**Yes, within a defined scope.** The new `buffett-sec` skill fetches SEC EDGAR facts, computes the assigned financial metrics and checks in Python, and directs the model to write a separate business-quality memo. Frozen inputs reproduce the same numerical report. The judgment follows a common rubric but need not be identical across model runs.

The latest assignment replaces the earlier Apple selection with **Costco (COST), the last five fiscal years**. It also overrides the earlier FAskills setup: do not install or invoke FAskills, and do not use its paid data sources for Lab 18. Its Buffett page was read only for philosophy; none of its scripts, orchestration, or data services supplied this analysis. The earlier installation predates this restriction and was not used here.

## Request developed for the AI

Codex drafted the following implementation request from the assignment; it is not represented as independently student-authored:

> Create my own Buffett business-quality skill using only keyless SEC EDGAR ticker mapping and companyfacts. Analyze COST using the last five fiscal-year-end dates from 10-K filings. Compute the specified accounting metrics and three checks in code, attach the XBRL tags and selected filing provenance, and preserve missing data rather than estimating it. Write a short Buffett-inspired model memo using only numbers printed by the script, with an own/watch/pass business-quality judgment and no price data. Build a Streamlit app showing the chart, table, checks, memo and every unsupported numeric token. Save the sources, results, and memo so another run can be checked.

## Philosophy and skill location

Read [Buffett’s FAskills page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/warren_buffett.md) as a reference only. Adapted themes: an understandable business, durable competitive advantage, dependable cash generation, thoughtful capital allocation, and conservative financing. Its forecasts, price targets, numeric scores, and valuation requirements are excluded. The memo is a simulation inspired by Buffett’s approach, not his actual opinion.

[Codex’s official skills page](https://learn.chatgpt.com/docs/build-skills) lists `$HOME/.agents/skills` as a user skill location. Installed skill: `/Users/ericboyd/.agents/skills/buffett-sec/SKILL.md`. The reviewable workspace copy is `Week 10/buffett-sec/`. The SKILL.md starts with a YAML name and a description of when to use it, and bundles `scripts/sec_facts.py` plus a concise philosophy reference. The installed script was run on the archived COST inputs and produced a byte-identical report.

To invoke in a new Codex turn: **Use $buffett-sec on COST and save the report and memo in Week 10/lab18_reports.** If the new skill does not appear immediately, restart Codex. Future changes to the workspace copy must also be copied to the installed skill.

## SEC-only sources and accounting rules

- [Ticker-to-CIK mapping](https://www.sec.gov/files/company_tickers.json).
- [COST companyfacts](https://data.sec.gov/api/xbrl/companyfacts/CIK0000909832.json); CIK padded to ten digits in the URL.
- [SEC EDGAR API documentation](https://www.sec.gov/search-filings/edgar-application-programming-interfaces).
- Requests identify Eric Boyd and his Git-configured email in the User-Agent, as required. No API key is used.

| Item | Implemented rule |
|---|---|
| Filings | Exact form `10-K`, annual fiscal period `FY`; never 10-Q or 10-K/A |
| Years | Latest five measured fiscal-year-end dates; do not group by the SEC `fy` field because comparative facts can carry the later filing’s fiscal year |
| Annual flows | Require a start/end annual duration of 330–380 elapsed days, accommodating retail fiscal years, and use the same selected start/end within a year |
| Repeat observations | Latest filed date wins; accession breaks filing-date ties; conflicting same-period facts stop rather than guess |
| Revenue | `RevenueFromContractWithCustomerExcludingAssessedTax`, then `Revenues` |
| Net income | `NetIncomeLoss` |
| Operating cash flow | `NetCashProvidedByUsedInOperatingActivities` |
| Capital spending | `PaymentsToAcquirePropertyPlantAndEquipment`, then `PaymentsToAcquireProductiveAssets` |
| Equity | `StockholdersEquity`, instant at the fiscal-year-end date |
| Liabilities | `Liabilities`, instant at the fiscal-year-end date |
| ROE | Net income / year-end equity × 100, displayed as a percent |
| Owner earnings | Operating cash flow − capital spending |
| Liabilities / equity | Liabilities / positive year-end equity |
| Missing raw value | `not found` |
| Missing derived input / check | `not known` |
| Equity at or below zero | ROE and liabilities/equity are `not known` |
| Units | USD source facts; monetary display in USD millions; ratios and percentages identified separately |

When aliases compete for the same period, the latest filing takes precedence; the specified preferred tag wins within that latest filing. Every selected raw value records tag, period, filing date, accession, form and units. Derived metrics show their tag formulas. Missing custom-taxonomy facts are not filled from another source. Annual-duration screening is a documented implementation convention, not an inference from the filing’s `fy` label.

The three checks are computed from unrounded values: **ROE ≥15% every year; owner earnings >0 every year; last owner earnings >first owner earnings**. All five years and required inputs must exist for a check to be known. The growth check is an endpoint comparison, not a monotonic-growth test. This latest-filed screen is not point-in-time backtest data.

For this assignment, “owner earnings” means the supplied operating-cash-flow-minus-total-capital-spending formula. It does not estimate maintenance capital expenditure or claim to implement Buffett’s full economic owner-earnings definition from his [1986 letter](https://www.berkshirehathaway.com/letters/1986.html).

## COST results — live SEC download

Downloaded November 3, 2026. Source bytes, hashes and retrieval timestamp are retained in `lab18_reports/`. The latest records include FY2026; no expected trend was substituted for actual data.

All monetary values below are USD millions; this table transcribes the script’s printed results.

| Fiscal-year-end | Revenue | Net income | Operating cash flow | Capital spending | Equity | ROE | Owner earnings |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2022-08-28 | 226,954.00 | 5,844.00 | 7,392.00 | 3,891.00 | 20,642.00 | 28.31% | 3,501.00 |
| 2023-09-03 | 242,290.00 | 6,292.00 | 11,068.00 | 4,323.00 | 25,058.00 | 25.11% | 6,745.00 |
| 2024-09-01 | 254,453.00 | 7,367.00 | 11,339.00 | 4,710.00 | 23,622.00 | 31.19% | 6,629.00 |
| 2025-08-31 | 275,235.00 | 8,099.00 | 13,335.00 | 5,498.00 | 29,164.00 | 27.77% | 7,837.00 |
| 2026-08-30 | 303,154.00 | 9,226.00 | 15,817.00 | 6,435.00 | 35,803.00 | 25.77% | 9,382.00 |

All three checks **pass**. Owner earnings and net income are higher at the FY2026 endpoint than FY2022, as expected. Owner earnings fell between FY2023 and FY2024; the memo explicitly acknowledges this.

Selected tags: revenue `RevenueFromContractWithCustomerExcludingAssessedTax`; net income `NetIncomeLoss`; operating cash flow `NetCashProvidedByUsedInOperatingActivities`; capital spending `PaymentsToAcquirePropertyPlantAndEquipment`; equity `StockholdersEquity`. The full report prints each year’s tags and derived formulas, plus liabilities and liabilities/equity. Recent facts cite accession `0000909832-26-000093`, filed October 7, 2026; older comparative values can come from earlier filings, individually recorded.

## Model memo and app

Saved memo: `lab18_reports/COST_memo.md`. Disposition: **Own the business**, a provisional business-quality assessment, not a conclusion about the stock price. It uses only printed numerical tokens and explains that the screen does not establish a moat or management integrity. No price feeds, target prices or valuation forecasts are used.

App: `buffett_app.py`. It provides a ticker form, SEC User-Agent input, cached live loading, owner-earnings/net-income chart, five-year table, three checks, expandable tags/provenance, report download, saved memo and memo download. The initial COST view loads the archived live report; the load/refresh button obtains SEC data with an hour cache. Each ticker needs a model-written memo through the skill; the app does not fabricate one when the ticker changes. The required attribution appears directly under the title.

The memo editor flags every unsupported numeric-token occurrence in red and lists its position. The saved memo audit found **no unsupported numbers**. The audit normalizes comma-separated/decimal representations and retains percentage units. It is a lexical check: a number printed somewhere can still be attached to the wrong year, unit, or claim. The model and student must review meaning separately. Spelled-out qualitative prose is not verified as a numerical calculation. An audit fingerprint ties the memo to its exact report and warns when either changes.

## Verification

- Skill frontmatter validator: passed.
- Five accounting tests: passed. Covered quarterly and 10-Q exclusion, latest-filing selection independent of `fy`, fallback-tag handling, conflicting facts, missing capital spending, zero equity, partial history, arithmetic, and unsupported-number detection.
- COST acceptance: five fiscal years FY2022–FY2026; both chart series higher at the endpoint; all three checks pass.
- Archived SEC replay: identical numerical report to the live run, including an execution of the installed skill script.
- Streamlit AppTest: five table rows and saved memo displayed without errors; injected unsupported `987654321` was flagged.
- Streamlit server started on localhost port 8504. The app is a local learning demonstration.

## Run commands

From `/Users/ericboyd/Fin 439`:

```sh
.venv-rates/bin/streamlit run 'Week 10/buffett_app.py' --server.headless true --server.port 8504 --server.address 127.0.0.1
```

Open http://127.0.0.1:8504.

To reproduce from the saved SEC inputs without network access:

```sh
python 'Week 10/buffett-sec/scripts/sec_facts.py' COST --facts-file 'Week 10/lab18_reports/COST_companyfacts.json' --tickers-file 'Week 10/lab18_reports/company_tickers.json' --output /tmp/lab18-replay
```

To test:

```sh
.venv-rates/bin/python -m unittest discover -s 'Week 10' -p 'test_buffett_sec.py' -v
.venv-rates/bin/python 'Week 10/verify_buffett_app.py'
```

For a fresh live run, use the script’s `--user-agent 'Your name your@email'` and `--output` arguments instead of the archived-file options. Validate a model-written memo with `--audit-memo` and `--report-json`; this saves the fingerprint. Streamlit and pandas are provided by the existing `.venv-rates`; the financial engine itself uses only Python’s standard library.

## AI disclosure and remaining review

Codex read the philosophy reference and official documentation, implemented and installed the new skill, downloaded SEC facts, ran the calculations and checks, wrote the model memo, built and tested the app, and drafted this record. No independent student review of source filings or model judgment is recorded. A passing numerical screen is evidence for a provisional business-quality judgment, not a verified durable competitive advantage or a price-based investment recommendation.

## Full submitted model memo

### COST — Own the business

*Buffett-inspired model judgment for the lab; not Warren Buffett's actual opinion. All dollar amounts below are USD millions. This judges business quality, not the stock's price.*

I would want to own this business on the financial evidence presented. Owner earnings rose from 3,501.00 in the earliest fiscal year to 9,382.00 in the latest, while net income rose from 5,844.00 to 9,226.00. Owner earnings stayed positive throughout, and ROE cleared 15% in every year. Those are the habits I look for in a business that can generate cash for its owners.

I would not mistake that screen for proof of a moat or management integrity. Owner earnings slipped from 6,745.00 to 6,629.00 before recovering; the endpoint growth check does not mean cash generation increased every year. The latest liabilities-to-equity ratio is 1.49, and the ROE calculation uses year-end equity, so I would examine how financing and distributions affect that return. The lab's owner earnings deducts all capital spending; it is a consistent cash-flow screen, not a maintenance-spending estimate.

I would change my assessment if owner earnings became persistently negative, returns on equity weakened, or further filing evidence undermined the durability of the cash generation. Until the business model and competitive position have been examined in detail, this is a provisional business-quality judgment. There is no conclusion here about whether the shares are attractively priced.

## Submission contents

The submission archive contains this write-up, the complete custom skill and SEC script, the Streamlit app, the COST memo, printed report and JSON, archived SEC inputs, numeric-audit record, tests, and dependency list. It excludes FAskills, virtual environments, and Python caches.

- [Skill instructions](buffett-sec/SKILL.md)
- [SEC calculation script](buffett-sec/scripts/sec_facts.py)
- [Streamlit app](buffett_app.py)
- [Full printed COST results with tags and filing provenance](lab18_reports/COST_report.md)
- [Saved model memo](lab18_reports/COST_memo.md)
- [Memo numeric audit](lab18_reports/COST_memo.audit.json)
- [Python dependencies](requirements-lab18.txt)

After extracting the ZIP, open this document inside its `Week 10` folder. On a different machine, create a virtual environment, install the dependency list, and run `streamlit run buffett_app.py` from that folder. The app's initial COST view uses the bundled SEC evidence without downloading again. Live refresh requires internet access and a valid SEC User-Agent. The author's full memo is included above so the write-up can also be read on its own.
