"""COST acceptance, unsupported-number UI, and frozen-input replay checks."""
import json
from pathlib import Path
import sys
from streamlit.testing.v1 import AppTest

root = Path(__file__).parent
sys.path.insert(0, str(root / 'buffett-sec' / 'scripts'))
import sec_facts as E
report = json.loads((root / 'lab18_reports/COST_report.json').read_text())
raw = json.loads((root / 'lab18_reports/COST_companyfacts.json').read_text())
replayed = E.analyze(raw, 'COST')
assert E.render(replayed) == report['printed'], 'Frozen inputs changed the numerical report'
records = report['records']
assert [r['fiscal_year_end'][:4] for r in records] == ['2022', '2023', '2024', '2025', '2026']
for field in ('owner_earnings', 'net_income'):
    assert records[-1]['metrics'][field]['value'] > records[0]['metrics'][field]['value']
assert set(report['checks'].values()) == {'pass'}
app = AppTest.from_file(str(root / 'buffett_app.py')).run(timeout=30)
assert not app.exception and not app.error, ([e.value for e in app.exception], [e.value for e in app.error])
assert len(app.dataframe[0].value) == 5
assert len(app.success) == 1
assert not app.warning, [w.value for w in app.warning]
app.text_area[0].set_value(app.text_area[0].value + '\nInvented profit: 987654321.').run(timeout=30)
assert not app.exception
assert any('Unsupported numbers' in e.value for e in app.error)
assert any('987654321' in str(df.value) for df in app.dataframe)
print('PASS: COST five-year endpoint trends and all checks; exact replay; app table/memo; unsupported-number flag.')
