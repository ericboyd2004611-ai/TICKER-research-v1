"""Run from repository root: .venv-rates/bin/streamlit run 'Week 10/buffett_app.py'."""
from datetime import date
import json
from pathlib import Path
import re
import sys

import pandas as pd
import streamlit as st

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'buffett-sec' / 'scripts'))
import sec_facts as engine

REPORTS = ROOT / 'lab18_reports'
st.set_page_config(page_title='Buffett business-quality desk', layout='wide')
st.title('Buffett business-quality desk')
st.caption('Data from SEC EDGAR; built with AI help, a learning demonstration, not investment advice.')

@st.cache_data(ttl=3600, show_spinner=False)
def download(ticker, user_agent, today):
    return engine.run(ticker, user_agent, REPORTS)

with st.sidebar:
    with st.form('company'):
        ticker = st.text_input('Ticker', 'COST').strip().upper()
        user_agent = st.text_input('SEC User-Agent: name and email', 'Eric Boyd ericboyd2004611@gmail.com Lab18 educational research')
        refresh = st.form_submit_button('Load / refresh SEC data')
    st.caption('Only SEC ticker mapping and companyfacts. No price or paid-service data.')
    st.caption('Saved memos are written by the model using the skill; loading a ticker does not invent a new memo.')

if not re.fullmatch(r'[A-Z0-9.-]+', ticker):
    st.error('Enter a valid ticker.')
    st.stop()
report_path = REPORTS / f'{ticker}_report.json'
try:
    if refresh or not report_path.exists():
        with st.spinner('Reading annual SEC facts…'):
            report = download(ticker, user_agent, date.today())
    else:
        report = json.loads(report_path.read_text())
except Exception as error:
    st.error(f'No verified SEC report: {error}')
    st.stop()

st.subheader(f"{report['ticker']} — {report['company']}")
st.caption(f"Downloaded {report['source']['retrieved_utc']} · 10-K only · latest filing wins · monetary values in USD millions")
if len(report['records']) < 5:
    st.warning('Fewer than five fiscal years found; the checks are not known.')
chart_rows, table_rows, provenance = [], [], []
for record in report['records']:
    chart = {'Fiscal-year-end': record['fiscal_year_end']}
    table = {'Fiscal-year-end': record['fiscal_year_end']}
    for field, metric in record['metrics'].items():
        table[field.replace('_', ' ').title()] = engine.display(metric, field)
        provenance.append({'Fiscal-year-end': record['fiscal_year_end'], 'Metric': field,
                           'Value': engine.display(metric, field), 'XBRL tag / formula': metric['tag'],
                           'Start': metric.get('start'), 'Filed': metric.get('filed'), 'Accession': metric.get('accn')})
        if field in ('owner_earnings', 'net_income'):
            chart[field.replace('_', ' ').title()] = metric['value'] / 1_000_000 if metric['value'] is not None else None
    chart_rows.append(chart)
    table_rows.append(table)
st.line_chart(pd.DataFrame(chart_rows).set_index('Fiscal-year-end'), color=['#005a9c', '#bd641c'], y_label='USD millions')
st.caption('Owner earnings = operating cash flow − capital spending. ROE = net income / year-end equity. Gaps are not filled.')
st.dataframe(pd.DataFrame(table_rows), hide_index=True, width='stretch')
st.subheader('Code-computed checks')
for name, result in report['checks'].items():
    st.write(f'**{name}: {result}**')
with st.expander('XBRL tags and selected filings'):
    st.dataframe(pd.DataFrame(provenance), hide_index=True, width='stretch')
    st.json(report['source'])
st.download_button('Download script output', report['printed'], f'{ticker}_report.md', 'text/markdown')

st.subheader('Model memo and numeric audit')
memo_path = REPORTS / f'{ticker}_memo.md'
if memo_path.exists():
    saved = memo_path.read_text()
else:
    saved = ''
    st.info(f'No model memo saved for {ticker}. Ask Codex to use $buffett-sec on {ticker}, then save its memo in lab18_reports.')
memo = st.text_area('Memo text (edit to test the audit)', saved, height=250,
                    key=f"memo-{ticker}-{report['analysis_sha256']}")
if memo:
    flags = engine.audit_memo(memo, report['printed'])
    marked = memo
    for flag in reversed(flags):
        marked = marked[:flag['start']] + ':red[**' + flag['number'] + '**]' + marked[flag['end']:]
    st.markdown(marked)
    if flags:
        st.error('Unsupported numbers are marked in red: they were not printed by the script.')
        st.dataframe(pd.DataFrame(flags), hide_index=True)
    else:
        st.success('Every numeric token in the memo appears in the script output.')
    st.caption('Token matching cannot prove a supported number has the correct unit, period, or interpretation. Human review is still required.')
    audit_path = memo_path.with_suffix('.audit.json')
    if audit_path.exists():
        binding = json.loads(audit_path.read_text())
        if binding['analysis_sha256'] != report['analysis_sha256'] or binding['memo_sha256'] != engine.digest(memo.encode()):
            st.warning('The memo is edited or its source report changed; rerun the skill memo audit before relying on it.')
    else:
        st.warning('The memo has not been bound to this report. Run the skill’s memo audit.')
    st.download_button('Download memo', memo, f'{ticker}_memo.md', 'text/markdown')
